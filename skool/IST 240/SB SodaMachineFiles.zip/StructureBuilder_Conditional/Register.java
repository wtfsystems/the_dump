
/**
 * @dependency Dispenser 
 */
public class Register
{
	private Float price;
	private String selection;
	private Float change;

	/**
	 * @param input 
	 * @param selection 
	 */
	public void verifyInput(Float input, String selection)
	{
	}

	public void checkForChange()
	{
	}
}

