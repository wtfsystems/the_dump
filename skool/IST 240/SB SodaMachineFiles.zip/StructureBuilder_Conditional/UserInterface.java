
/**
 * @dependency Register 
 */
public class UserInterface
{
	private Float inputAmount;
	private String selectedSoda;
	private StringBuffer message;
	public void inputCash()
	{
	}

	public void makeSelection()
	{
	}

	/**
	 * @param c 
	 */
	public void returnChange()
	{
	}

	public void deliverSelection()
	{
	}

	/**
	 * @param m 
	 * @param s 
	 */
	public void displayMessage()
	{
	}
}

