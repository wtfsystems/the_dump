
/**
 * @dependency UserInterface 
 */
public class Dispenser
{
	private String selection;

	/**
	 * @param sodaType 
	 * @param s 
	 */
	public void dispenseSoda()
	{
	}
}

