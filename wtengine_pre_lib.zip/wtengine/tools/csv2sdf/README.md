
Short Python script for converting CSV files for use with the WTEngine.

The engine will process this file and feed timed events to the entities.

SDF stands for "Spawner Data File" or "Super Dimension Fortress", which ever you perfer.
